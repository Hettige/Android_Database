package com.mithunhettige.sqllite;

import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
{
    DatabaseHelper myDb;
    EditText editname,editSurname,editMarks,editId;
    Button btnAddData;
    Button btnViewAll;
    Button btnUpdate;
    Button btnDelete;
    Button btnClearAll;
    Button btnViewaData;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myDb = new DatabaseHelper(this);

        editname = (EditText)findViewById(R.id.editText_name);
        editSurname = (EditText)findViewById(R.id.editText_surname);
        editMarks = (EditText)findViewById(R.id.editText_marks);
        editId = (EditText) findViewById(R.id.editText_Id);
        btnAddData = (Button) findViewById(R.id.button_add);
        btnViewAll = (Button)findViewById(R.id.button_view);
        btnUpdate = (Button)findViewById(R.id.button_update);
        btnDelete = (Button)findViewById(R.id.button_delete);
        btnClearAll = (Button)findViewById(R.id.button_clear);
        btnViewaData=(Button)findViewById(R.id.button_viwD);

        AddData();
        viewAll();
        UpdateData();
        DeleteData();
        ClearData();
        ViewAData();
    }

    public void AddData()
    {
        btnAddData.setOnClickListener(
                new View.OnClickListener()
                {
                    @Override
                    public void onClick(View v)
                    {
                       boolean isInserted = myDb.insertData(editname.getText().toString(),editSurname.getText().toString(),editMarks.getText().toString());

                       if(isInserted==true)
                       {
                           Toast.makeText(MainActivity.this,"Data Inserted Successfully",Toast.LENGTH_LONG).show();
                       }
                       else
                       {
                           Toast.makeText(MainActivity.this,"Data Inserted Unsuccessfully",Toast.LENGTH_LONG).show();
                       }
                    }
                }
        );
    }

    public void viewAll()
    {
        btnViewAll.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                      Cursor res = myDb.getAllData();
                      if(res.getCount()==0)
                      {
                          showMessage("Error","No Data Found to Show");
                          return;
                      }
                      StringBuffer buffer = new StringBuffer();
                      while (res.moveToNext())
                      {
                          buffer.append("Id : "+ res.getString(0)+"\n");
                          buffer.append("First Name : "+ res.getString(1)+"\n");
                          buffer.append("Second Name : "+ res.getString(2)+"\n");
                          buffer.append("Marks : "+ res.getString(3)+"\n\n");
                      }
                        showMessage("Data",buffer.toString());
                    }
                }
        );
    }
    public void showMessage(String Title,String Message)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(Title);
        builder.setMessage(Message);
        builder.show();
    }

    public void UpdateData()
    {
        btnUpdate.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        boolean isUpdate = myDb.updateData(editId.getText().toString(),editname.getText().toString(),editSurname.getText().toString(),editMarks.getText().toString());
                        if(isUpdate==true)
                        {
                            Toast.makeText(MainActivity.this,"Data is Updated Successfully",Toast.LENGTH_LONG).show();
                        }
                        else
                        {
                            Toast.makeText(MainActivity.this,"Data is Not Updated",Toast.LENGTH_LONG).show();
                        }
                    }
                }
        );
    }

    public void DeleteData()
    {
        btnDelete.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Integer deletedRows = myDb.DeleteData(editId.getText().toString());
                        if(deletedRows > 0)
                        {
                            Toast.makeText(MainActivity.this,"Data is Deleted Successfully",Toast.LENGTH_LONG).show();
                        }
                        else
                        {
                            Toast.makeText(MainActivity.this,"Data is Not Deleted",Toast.LENGTH_LONG).show();
                        }
                    }
                }
        );
    }

    public void ClearData()
    {
        btnClearAll.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        editId.setText("");
                        editname.setText("");
                        editSurname.setText("");
                        editMarks.setText("");
                    }
                }
        );
    }

    public void ViewAData()
    {
        btnViewaData.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v)
                    {
                        Cursor res = myDb.rawQuery(editId.getText().toString());
                        if(res.getCount()==0)
                        {
                            showMessage("Error","No Data Found to Show");
                            return;
                        }
                        StringBuffer buffer = new StringBuffer();
                        while (res.moveToNext())
                        {
                            buffer.append("Id : "+ res.getString(0)+"\n");
                            buffer.append("First Name : "+ res.getString(1)+"\n");
                            buffer.append("Second Name : "+ res.getString(2)+"\n");
                            buffer.append("Marks : "+ res.getString(3)+"\n\n");
                        }
                        showMessage("Data",buffer.toString());
                    }
                }
        );
    }
}
